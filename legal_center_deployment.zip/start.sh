#!/bin/bash
echo "🚀 Starting from start.sh..."
python railway_start.py 